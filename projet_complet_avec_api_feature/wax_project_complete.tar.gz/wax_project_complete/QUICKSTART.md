# ⚡ QUICKSTART - Démarrage en 5 Minutes

Guide ultra-rapide pour démarrer avec le pipeline WAX.

---

## 🎯 Prérequis

- Python 3.8+
- PySpark
- Accès à un cluster Databricks (optionnel pour tests locaux)

---

## 🚀 Installation (2 min)

### 1. Extraire le projet

```bash
# Si vous avez un ZIP
unzip wax_project_complete.zip
cd wax_project_complete

# Ou si vous clonez depuis Git
git clone <repo-url>
cd wax_project_complete
```

### 2. Installer les dépendances

```bash
pip install -r requirements.txt
```

✅ **Installation terminée !**

---

## 🔧 Configuration (1 min)

### Option A : Avec API (Recommandé)

```bash
# Démarrer l'API de configuration
cd config_api
python start_api.py
```

L'API démarre sur `http://localhost:5000`

### Option B : Sans API (Manuel)

```python
from src.config import Config

config = Config(
    catalog="abu_catalog",
    schema_files="databricksassetbundletest",
    volume="externalvolumetes",
    schema_tables="gdp_poc_dev",
    env="dev"
)
```

---

## 🧪 Test Rapide (2 min)

### Test 1 : API de Configuration

```bash
# Health check
curl http://localhost:5000/health

# Récupérer config DEV
curl http://localhost:5000/config/dev
```

**Résultat attendu :**
```json
{
  "status": "success",
  "environment": "dev",
  "data": {
    "catalog": "abu_catalog",
    ...
  }
}
```

### Test 2 : Module de Dézipage

```python
from pyspark.sql import SparkSession
from src.config import create_config_from_api
from src.unzip_module import UnzipManager

# Initialiser
spark = SparkSession.builder.appName("WAX-Test").getOrCreate()
config = create_config_from_api(env="dev")

# Tester dézipage
unzip_manager = UnzipManager(spark, config)
result = unzip_manager.process_all_zips()

print(f"Status: {result['status']}")
print(f"ZIP extraits: {result['zip_count']}")
```

### Test 3 : Tests Automatiques

```bash
cd tests
python test_config_system.py
```

**Résultat attendu :**
```
Total : 8 tests
✅ Réussis : 8
❌ Échoués : 0

🎉 TOUS LES TESTS SONT PASSÉS !
```

---

## 📦 Structure du Projet

```
wax_project_complete/
├── src/              # 🐍 Code source Python
├── config_api/       # 🌐 API de configuration
├── tests/            # 🧪 Tests automatiques
├── docs/             # 📚 Documentation
└── README.md         # 📖 Guide complet
```

---

## 🎮 Utilisation Basique

### Exécuter le Pipeline Complet

```python
from pyspark.sql import SparkSession
from src.config import create_config_from_api
from src.unzip_module import UnzipManager
from src.main import main as waxng_ingestion

# 1. Initialiser Spark
spark = SparkSession.builder.appName("WAX").getOrCreate()

# 2. Récupérer configuration
config = create_config_from_api(env="dev")
config.print_config()

# 3. Module 1 : Dézipage
print("\n🔹 MODULE 1 : DÉZIPAGE")
unzip_manager = UnzipManager(spark, config)
unzip_result = unzip_manager.process_all_zips()

# 4. Module 2 & 3 : Auto Loader + Ingestion
print("\n🔹 MODULES 2 & 3 : INGESTION")
ingestion_result = waxng_ingestion()

print("\n✅ PIPELINE TERMINÉ !")
```

---

## 🔗 Tester avec Postman

### Importer la Collection

1. Ouvrir Postman
2. **Import** → Fichier
3. Sélectionner `docs/WAX_Config_API.postman_collection.json`
4. ✅ Collection prête avec 11 requêtes !

### Requêtes Principales

| Requête | URL | Description |
|---------|-----|-------------|
| Health Check | `GET /health` | Vérifier API |
| Get DEV Config | `GET /config/dev` | Config dev |
| Create TEST | `POST /config/test` | Créer config |
| Validate | `GET /config/dev/validate` | Valider |

---

## 📊 Exemple Complet

```python
# exemple_simple.py

from pyspark.sql import SparkSession
from src.config import create_config_from_api
from src.unzip_module import UnzipManager

def main():
    # Configuration
    spark = SparkSession.builder \
        .appName("WAX-Example") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .getOrCreate()
    
    # Récupérer config depuis API
    config = create_config_from_api(env="dev")
    
    # Afficher configuration
    config.print_config()
    
    # Dézipper les fichiers
    unzip_manager = UnzipManager(spark, config)
    result = unzip_manager.process_all_zips()
    
    # Résumé
    if result["status"] == "SUCCESS":
        print(f"✅ {result['zip_count']} ZIP traités avec succès")
        print(f"📄 {result['total_files']} fichiers extraits")
    else:
        print(f"⚠️  Traitement partiel : {result['failed_count']} échecs")
    
    return result

if __name__ == "__main__":
    main()
```

**Exécuter :**
```bash
python exemple_simple.py
```

---

## 🌍 Changer d'Environnement

### Via Variable d'Environnement

```bash
export PIPELINE_ENV=prd
python votre_script.py
```

### Via Code

```python
# DEV
config_dev = create_config_from_api(env="dev")

# INT
config_int = create_config_from_api(env="int")

# PROD
config_prd = create_config_from_api(env="prd")
```

### Via Databricks Widget

```python
dbutils.widgets.dropdown("env", "dev", ["dev", "int", "prd"])
env = dbutils.widgets.get("env")
config = create_config_from_api(env=env)
```

---

## 📚 Documentation Détaillée

Pour aller plus loin :

| Guide | Description |
|-------|-------------|
| [README.md](README.md) | Documentation complète du projet |
| [docs/README.md](docs/README.md) | Guide API détaillé |
| [docs/POSTMAN_GUIDE.md](docs/POSTMAN_GUIDE.md) | Tests Postman complets |
| [docs/DATABRICKS_DEPLOYMENT.md](docs/DATABRICKS_DEPLOYMENT.md) | Déploiement sur Databricks |
| [docs/CHANGELOG_UNZIP.md](docs/CHANGELOG_UNZIP.md) | Modifications module unzip |

---

## ✅ Checklist de Démarrage

- [ ] Projet extrait
- [ ] Dépendances installées (`pip install -r requirements.txt`)
- [ ] API démarrée (`python start_api.py`)
- [ ] Health check OK (`curl http://localhost:5000/health`)
- [ ] Config récupérée (`curl http://localhost:5000/config/dev`)
- [ ] Tests passés (`python test_config_system.py`)
- [ ] Pipeline testé sur DEV

---

## 🚨 Problèmes Courants

### ❌ Erreur : ModuleNotFoundError

```bash
# Solution : Installer les dépendances
pip install -r requirements.txt
```

### ❌ Erreur : Connection refused (API)

```bash
# Solution : Démarrer l'API
cd config_api
python start_api.py
```

### ❌ Erreur : Volume introuvable

```python
# Solution : Vérifier les paramètres Unity Catalog
config = Config(
    catalog="abu_catalog",
    schema_files="databricksassetbundletest",
    volume="externalvolumetes",  # Vérifier ce nom
    schema_tables="gdp_poc_dev"
)

# Valider
validation = config.validate_paths()
print(validation)
```

---

## 🎯 Prochaines Étapes

1. ✅ Lire la [documentation complète](README.md)
2. 🧪 Tester sur votre environnement DEV
3. 📊 Explorer les [dashboards](docs/README.md#-observabilité)
4. 🚀 Déployer sur Databricks ([guide](docs/DATABRICKS_DEPLOYMENT.md))

---

## 💡 Astuces

### One-Liner pour Tout Tester

```bash
cd config_api && python start_api.py & sleep 2 && cd ../tests && python test_config_system.py
```

### Activer le Mode Debug

```python
import os
os.environ['DEBUG'] = 'true'
```

### Vérifier la Configuration

```python
from src.config import create_config_from_api

config = create_config_from_api(env="dev")
print(config.to_dict())
```

---

## 📞 Besoin d'Aide ?

- 📖 Consulter [README.md](README.md)
- 🔍 Rechercher dans `docs/`
- 🧪 Exécuter les tests : `python test_config_system.py`

---

**🎉 Félicitations ! Vous êtes prêt à utiliser le pipeline WAX !**

Pour une utilisation avancée, consultez [README.md](README.md)
