# 📋 Mapping des Spécifications vers l'Implémentation

Ce document explique comment les spécifications Gherkin sont implémentées dans le code WAX.

---

## 📚 Fichier de Spécifications

Voir : `specs/data_ingestion.feature`

---

## 🎯 Vue d'Ensemble

Les spécifications définissent les règles métier pour l'ingestion de données. Le pipeline WAX implémente ces règles à travers ses 3 modules principaux.

---

## 📦 Structure Standard des Tables Delta

### Spécification (Background)

```gherkin
Given the standard format for OUTPUT_DATE is "yyyy-MM-dd HH:mm:ss"
And the first four columns in all output Delta Tables are:
| FILE_LINE_ID | FILE_NAME_RECEIVED | FILE_EXTRACTION_DATE | FILE_PROCESS_DATE |
And all input file columns are preserved in the output Delta Tables
```

### Implémentation

**Fichier : `src/delta_manager.py`**

```python
def create_or_get_table(self, table_name, schema, partitioned=True):
    # Ajout automatique des 4 colonnes standards
    extended_fields = [
        StructField("FILE_LINE_ID", LongType(), False),
        StructField("FILE_NAME_RECEIVED", StringType(), False),
        StructField("FILE_EXTRACTION_DATE", TimestampType(), False),
        StructField("FILE_PROCESS_DATE", TimestampType(), False)
    ]
    
    # Puis ajout des colonnes du fichier source
    extended_fields.extend(schema.fields)
```

**Format des dates : `src/config.py`**

```python
self.date_patterns = [
    "yyyy-MM-dd HH:mm:ss",  # Format standard OUTPUT_DATE
    "dd/MM/yyyy HH:mm:ss",
    "yyyy-MM-dd",
    # ... autres patterns
]
```

---

## 📥 Module 1 : Dézipage

### Spécification

```gherkin
Scenario: Zipped file received
Given a file is received
And the file is a zip archive
When the file is processed
Then the file is unzipped
And the extracted files are copied to the raw destination folder
```

### Implémentation

**Fichier : `src/unzip_module.py`**

```python
class UnzipManager:
    def process_all_zips(self):
        # Lister tous les ZIP dans /input/zip/
        zip_files = [f for f in all_files if f.endswith('.zip')]
        
        for zip_file in zip_files:
            # Extraire vers /extracted/<table_name>/
            result = self._extract_single_zip(zip_file)
            
            if result["status"] == "SUCCESS":
                # Supprimer le ZIP après extraction
                self._delete_zip(zip_file)
```

**Mapping Table depuis Nom de Fichier :**

```python
# Ex: site_20250902.zip → extracted/site/
base_name = zip_filename.replace('.zip', '')
table_name = base_name.split('_')[0]  # 'site'
extract_dir = os.path.join(self.extract_base_dir_fs, table_name)
```

---

## 🔄 Module 2 : Auto Loader

### Spécification

```gherkin
Scenario: Files must be automatically ingested
Given it exists a way to supervise the arrival of a file
When the file arrives in a specific storage
Then the Databricks job to ingest data is automatically launched
```

### Implémentation

**Fichier : `src/autoloader_module.py`**

```python
class AutoLoaderManager:
    def process_table(self, table_name, config_row):
        # Lecture automatique des nouveaux fichiers
        df = (spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", input_format)
            .option("cloudFiles.schemaLocation", schema_location)
            .load(source_path))
        
        # Écriture avec checkpoint pour traçabilité
        query = (df.writeStream
            .option("checkpointLocation", checkpoint_path)
            .trigger(once=True)
            .start())
```

---

## ✅ Validation des Données

### Spécification : Filename Pattern

```gherkin
Given +Filename Pattern to do the mapping between the name of the file
Then validate filename matches the pattern
```

### Implémentation

**Fichier : `src/validator.py`**

```python
def validate_filename(self, filename, expected_pattern):
    """
    Valide que le nom de fichier correspond au pattern attendu
    
    Exemple:
    - Pattern: billing_yyyymmdd_hhMMss.csv
    - Fichier: billing_20251016_101112.csv
    - Extraction: date = 16/10/2025 11:11:12
    """
    
    # Extraire la date du filename
    date_match = self._extract_date_from_filename(filename)
    
    if not date_match:
        return {
            "valid": False,
            "error": "Filename does not match expected date pattern"
        }
```

### Spécification : Column Validation

```gherkin
+Column Name | Name of the column | YES
+Is Nullable | Option to manage the empty fields | NO | false
+Field type  | Type of the column | YES
```

### Implémentation

**Fichier : `src/validator.py`**

```python
def validate_columns_presence(self, df, expected_columns):
    """Valide la présence des colonnes attendues"""
    missing = set(expected_columns) - set(df.columns)
    
    if missing:
        return {
            "valid": False,
            "missing_columns": list(missing)
        }

def validate_nullable_constraints(self, df, nullable_config):
    """Valide les contraintes de nullabilité"""
    for col_name, nullable in nullable_config.items():
        if not nullable:
            null_count = df.filter(col(col_name).isNull()).count()
            if null_count > 0:
                errors.append({
                    "column": col_name,
                    "error": f"{null_count} null values found"
                })
```

---

## 🔧 Traitement des Colonnes

### Spécification : Field Type

```gherkin
+Field type | Type of the column | YES | NA
Possible values: STRING, INT, LONG, DOUBLE, DATE, TIMESTAMP, etc.
```

### Implémentation

**Fichier : `src/column_processor.py`**

```python
def process_column(self, df, col_name, col_config):
    """
    Applique le typage selon la configuration
    
    Types supportés:
    - STRING, INT, LONG, BIGINT, DOUBLE, FLOAT, DECIMAL
    - BOOLEAN
    - DATE, TIMESTAMP
    """
    
    field_type = col_config.get('field_type', 'STRING')
    
    if field_type == 'DATE':
        df = self._apply_date_conversion(df, col_name, col_config)
    elif field_type == 'INT':
        df = self._apply_int_conversion(df, col_name, col_config)
    # ... autres types
```

### Spécification : Transformation Type

```gherkin
Scenario: Considers the value of transformation type is date
Given Field-type is date
When Transformation type date
Then create the column by Applying the pattern defined in "Transformation Pattern"

Example: 
- Input date = 14/06/2021 16:33
- Transformation Pattern = dd/MM/yyyy HH:mm
- Result: 14/06/2021 16:33 (parsed as timestamp)
```

### Implémentation

**Fichier : `src/column_processor.py`**

```python
def _apply_date_conversion(self, df, col_name, col_config):
    """
    Convertit une colonne en date selon le pattern
    
    Lit "Transformation Pattern" depuis config Excel
    """
    transformation_pattern = col_config.get('transformation_pattern')
    
    if transformation_pattern:
        # Utiliser le pattern spécifié
        df = df.withColumn(
            col_name,
            to_timestamp(col(col_name), transformation_pattern)
        )
    else:
        # Essayer plusieurs patterns standards
        for pattern in self.config.date_patterns:
            df = df.withColumn(
                col_name,
                coalesce(
                    to_timestamp(col(col_name), pattern),
                    col(col_name)
                )
            )
```

---

## ⚠️ Gestion des Erreurs

### Spécification : ICT (Invalid Column per Line Tolerance)

```gherkin
Rule: ICT Rule
Given compute the ICT = ICT number / total number of columns
When ICT calculated is greater than or equal to ICT parameter
Then Reject the line from Last table
Then Increment the number of Rejected Lines
Then Apply the RLT Rule
```

### Implémentation

**Fichier : `src/column_processor.py`**

```python
def apply_error_action(self, df, error_col, ict_threshold):
    """
    Applique l'action d'erreur selon ICT
    
    Args:
        ict_threshold: Seuil de tolérance (ex: 10%)
    
    Modes:
    - REJECT: Supprime les lignes avec erreurs
    - ICT_DRIVEN: Supprime si % erreurs > seuil
    - LOG_ONLY: Log uniquement, garde tout
    """
    
    if error_action == "ICT_DRIVEN":
        # Calculer % erreurs par ligne
        total_cols = len(df.columns)
        df = df.withColumn(
            "error_percentage",
            (col(error_col) / total_cols) * 100
        )
        
        # Filtrer les lignes avec erreurs < seuil
        valid_df = df.filter(col("error_percentage") < ict_threshold)
        rejected_df = df.filter(col("error_percentage") >= ict_threshold)
        
        # Logger les rejets
        self._log_rejected_lines(rejected_df, "ICT exceeded")
```

### Spécification : RLT (Rejected Line per File Tolerance)

```gherkin
Rule: RLT Rule
Given compute the RLT = number of rejected lines / total number of lines
When RLT calculated is greater than or equal to RLT parametered
Then the file is rejected
Then Increment the number of Rejected Files
```

### Implémentation

**Fichier : `src/validator.py`**

```python
def check_rlt_threshold(self, total_rows, rejected_rows, rlt_threshold):
    """
    Vérifie si le fichier doit être rejeté selon RLT
    
    Args:
        total_rows: Nombre total de lignes
        rejected_rows: Nombre de lignes rejetées
        rlt_threshold: Seuil RLT (ex: 10%)
    
    Returns:
        bool: True si fichier doit être rejeté
    """
    
    if total_rows == 0:
        return False
    
    rlt_percentage = (rejected_rows / total_rows) * 100
    
    if rlt_percentage >= rlt_threshold:
        self.logger.log_quality_error(
            filename=filename,
            error_type="RLT_EXCEEDED",
            error_message=f"RLT {rlt_percentage:.2f}% >= {rlt_threshold}%",
            rejected_rows=rejected_rows
        )
        return True  # Rejeter le fichier
    
    return False
```

---

## 🔄 Modes d'Ingestion

### Spécification

```gherkin
+Ingestion mode | To define how the data will be ingested | YES

Modes:
- FULL_SNAPSHOT: Écrase tout
- DELTA_FROM_FLOW: Append simple (incremental)
- DELTA_FROM_NON_HISTORIZED: Merge + update
- DELTA_FROM_HISTORIZED: Append avec historique
- FULL_KEY_REPLACE: Delete + insert
```

### Implémentation

**Fichier : `src/ingestion.py`**

```python
class IngestionManager:
    def ingest_data(self, df, table_name, ingestion_mode, merge_keys=None):
        """
        Ingère les données selon le mode configuré
        """
        
        if ingestion_mode == "FULL_SNAPSHOT":
            # Écrase tout
            df.write.format("delta") \
                .mode("overwrite") \
                .saveAsTable(table_name)
        
        elif ingestion_mode == "DELTA_FROM_FLOW":
            # Append simple
            df.write.format("delta") \
                .mode("append") \
                .saveAsTable(table_name)
        
        elif ingestion_mode == "DELTA_FROM_NON_HISTORIZED":
            # Merge avec update
            self._merge_non_historized(df, table_name, merge_keys)
        
        elif ingestion_mode == "DELTA_FROM_HISTORIZED":
            # Append avec historique
            df.write.format("delta") \
                .mode("append") \
                .saveAsTable(table_name)
        
        elif ingestion_mode == "FULL_KEY_REPLACE":
            # Delete + insert par clé
            self._replace_by_keys(df, table_name, merge_keys)
```

**Exemple Merge :**

```python
def _merge_non_historized(self, df, table_name, merge_keys):
    """
    Merge avec update des enregistrements existants
    
    Exemple:
    - Clé: customer_id
    - Si existe: UPDATE
    - Sinon: INSERT
    """
    
    deltaTable = DeltaTable.forName(self.spark, table_name)
    
    merge_condition = " AND ".join([
        f"target.{key} = source.{key}" 
        for key in merge_keys
    ])
    
    deltaTable.alias("target").merge(
        df.alias("source"),
        merge_condition
    ).whenMatchedUpdateAll() \
     .whenNotMatchedInsertAll() \
     .execute()
```

---

## 📊 Logging et Métriques

### Spécification

```gherkin
Scenario: writes the final execution report with all metrics of each file
Given each file in input
Then write the execution report with all metrics
```

### Implémentation

**Fichier : `src/logger_manager.py`**

```python
class LoggerManager:
    def log_execution(self, metrics):
        """
        Log l'exécution avec métriques complètes
        
        Métriques:
        - filename
        - row_count_input
        - row_count_output
        - row_count_rejected
        - error_count
        - execution_time
        - status (SUCCESS/FAILED)
        """
        
        log_df = self.spark.createDataFrame([{
            "execution_id": str(uuid.uuid4()),
            "table_name": metrics["table_name"],
            "filename": metrics["filename"],
            "row_count_input": metrics["row_count_input"],
            "row_count_output": metrics["row_count_output"],
            "row_count_rejected": metrics.get("row_count_rejected", 0),
            "error_count": metrics.get("error_count", 0),
            "execution_time_seconds": metrics["execution_time"],
            "status": metrics["status"],
            "timestamp": current_timestamp()
        }])
        
        # Écrire dans table de logs
        log_df.write.format("delta") \
            .mode("append") \
            .saveAsTable("wax_execution_logs")
```

---

## 📈 Dashboards et Observabilité

### Spécification (Implicite)

Besoin de visualiser l'état du pipeline et les erreurs

### Implémentation

**Fichier : `src/dashboards.py`**

```python
class DashboardManager:
    def show_last_executions(self):
        """Dashboard des dernières exécutions"""
        
        query = """
        SELECT 
            table_name,
            filename,
            row_count_input,
            row_count_output,
            row_count_rejected,
            error_count,
            status,
            timestamp
        FROM wax_execution_logs
        ORDER BY timestamp DESC
        LIMIT 20
        """
        
        display(self.spark.sql(query))
    
    def show_quality_errors(self):
        """Dashboard des erreurs qualité"""
        
        query = """
        SELECT 
            error_type,
            COUNT(*) as error_count,
            MAX(timestamp) as last_occurrence
        FROM wax_data_quality_errors
        WHERE DATE(timestamp) >= CURRENT_DATE - 7
        GROUP BY error_type
        ORDER BY error_count DESC
        """
        
        display(self.spark.sql(query))
```

---

## 🔧 Partitionnement

### Spécification

```gherkin
+Partition by | Describes the partitioning of the files | YES | yyyy/mm/dd/hhmmss
```

### Implémentation

**Fichier : `src/delta_manager.py`**

```python
def create_or_get_table(self, table_name, schema, partitioned=True):
    """
    Crée table Delta avec partitionnement automatique
    
    Partitions:
    - year (yyyy)
    - month (mm)
    - day (dd)
    
    Basé sur FILE_PROCESS_DATE
    """
    
    if partitioned:
        # Ajouter colonnes de partition
        df = df.withColumn("year", year(col("FILE_PROCESS_DATE")))
        df = df.withColumn("month", month(col("FILE_PROCESS_DATE")))
        df = df.withColumn("day", dayofmonth(col("FILE_PROCESS_DATE")))
        
        # Créer table partitionnée
        df.write.format("delta") \
            .partitionBy("year", "month", "day") \
            .saveAsTable(table_name)
```

---

## 🧪 Tests

### Fichier : `tests/test_config_system.py`

Tests automatiques de la configuration API :

```python
def test_health_check():
    """Test 1: Vérifier que l'API est accessible"""
    response = client.health_check()
    assert response["status"] == "healthy"

def test_get_all_configs():
    """Test 2: Récupérer toutes les configurations"""
    response = client.get_all_configs()
    assert "dev" in response["data"]
    assert "int" in response["data"]

# ... 6 autres tests
```

---

## 📋 Checklist d'Implémentation

### ✅ Implémenté

- [x] Structure standard 4 colonnes (FILE_LINE_ID, FILE_NAME_RECEIVED, etc.)
- [x] Format date OUTPUT_DATE (yyyy-MM-dd HH:mm:ss)
- [x] Dézipage automatique
- [x] Extraction date depuis filename
- [x] Validation colonnes attendues
- [x] Validation types de données
- [x] Validation nullabilité
- [x] Gestion erreurs : REJECT, ICT_DRIVEN, LOG_ONLY
- [x] ICT (Invalid Column per Line Tolerance)
- [x] RLT (Rejected Line per File Tolerance)
- [x] 5 modes d'ingestion
- [x] Partitionnement yyyy/mm/dd
- [x] Logging exécution
- [x] Logging qualité
- [x] Dashboards observabilité
- [x] API configuration multi-env
- [x] Tests automatiques

### ⚠️ Partiellement Implémenté

- [~] Fail Fast Option (logique présente, paramètre à exposer)
- [~] Invalid Lines Generated Table (logique présente, à activer)
- [~] Transformation regex (structure présente, à compléter)

### ❌ Non Implémenté (Hors Scope R1)

- [ ] File recovery automatique
- [ ] Late file ingestion
- [ ] Batch processing avancé
- [ ] XML format
- [ ] Monitoring temps réel

---

## 📚 Références

| Spécification | Implémentation | Fichier |
|---------------|----------------|---------|
| Background (Structure tables) | DeltaManager | `src/delta_manager.py` |
| Dézipage | UnzipManager | `src/unzip_module.py` |
| Auto Loader | AutoLoaderManager | `src/autoloader_module.py` |
| Validation | Validator | `src/validator.py` |
| Typage colonnes | ColumnProcessor | `src/column_processor.py` |
| Modes ingestion | IngestionManager | `src/ingestion.py` |
| Logging | LoggerManager | `src/logger_manager.py` |
| Dashboards | DashboardManager | `src/dashboards.py` |
| Configuration | Config + API | `src/config.py` + `config_api/` |

---

## 🎯 Pour Aller Plus Loin

### Ajouter de Nouveaux Tests BDD

Créer des tests Behave Python :

```bash
pip install behave
```

Structure :
```
tests/
├── features/
│   ├── ingestion.feature     # Scénarios Gherkin
│   └── steps/
│       └── ingestion_steps.py  # Implémentation steps
```

### Exemple Step Definition

```python
from behave import given, when, then

@given('a file is received')
def step_file_received(context):
    context.filename = "test_20250115.csv"

@when('the file is processed')
def step_file_processed(context):
    context.unzip_manager = UnzipManager(spark, config)
    context.result = context.unzip_manager.process_all_zips()

@then('the file is unzipped')
def step_file_unzipped(context):
    assert context.result["status"] == "SUCCESS"
```

---

✅ **Le code WAX implémente fidèlement les spécifications Gherkin !**

Voir `specs/data_ingestion.feature` pour le fichier complet des spécifications.
