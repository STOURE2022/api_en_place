# 🗑️ MODIFICATIONS : Suppression ZIP après Extraction

## 📋 Résumé des Changements

Les fichiers ZIP sont maintenant **supprimés directement** après extraction, au lieu d'être archivés dans `/processed/`.

---

## 🔧 Fichiers Modifiés

### 1. **config.py**

**Suppressions :**
- ❌ `self.archive_dir = f"{self.zip_dir}/processed"` (ligne supprimée)
- ❌ Référence à `archive_dir` dans `dirs_to_create`
- ❌ Référence à `archive_dir` dans `to_dict()`

**Avant :**
```python
# Archive pour ZIP traités
self.archive_dir = f"{self.zip_dir}/processed"

# Dans dirs_to_create
dirs_to_create = [
    self.input_base,
    self.zip_dir,
    ...
    self.archive_dir,  # ❌ Supprimé
    ...
]
```

**Après :**
```python
# Plus de répertoire archive

# Dans dirs_to_create
dirs_to_create = [
    self.input_base,
    self.zip_dir,
    ...
    # archive_dir supprimé
    ...
]
```

---

### 2. **unzip_module.py**

**Modifications principales :**

#### A. Suppression des références à archive_dir

**Avant :**
```python
def __init__(self, spark, config):
    self.spark = spark
    self.config = config
    
    self.zip_dir = f"{config.volume_base}/input/zip"
    self.extract_base_dir = f"{config.volume_base}/extracted"
    self.archive_dir = f"{config.volume_base}/input/zip/processed"  # ❌
    
    self.zip_dir_fs = self._to_fs_path(self.zip_dir)
    self.extract_base_dir_fs = self._to_fs_path(self.extract_base_dir)
    self.archive_dir_fs = self._to_fs_path(self.archive_dir)  # ❌
```

**Après :**
```python
def __init__(self, spark, config):
    self.spark = spark
    self.config = config
    
    self.zip_dir = f"{config.volume_base}/input/zip"
    self.extract_base_dir = f"{config.volume_base}/extracted"
    # archive_dir supprimé ✅
    
    self.zip_dir_fs = self._to_fs_path(self.zip_dir)
    self.extract_base_dir_fs = self._to_fs_path(self.extract_base_dir)
    # archive_dir_fs supprimé ✅
```

#### B. Suppression de la création du répertoire archive

**Avant :**
```python
# Créer répertoire extraction si nécessaire
os.makedirs(self.extract_base_dir_fs, exist_ok=True)
os.makedirs(self.archive_dir_fs, exist_ok=True)  # ❌
```

**Après :**
```python
# Créer répertoire extraction si nécessaire
os.makedirs(self.extract_base_dir_fs, exist_ok=True)
# Plus de création archive ✅
```

#### C. Remplacement de l'archivage par suppression

**Avant :**
```python
if result["status"] == "SUCCESS":
    extracted_count += 1
    total_files += result["file_count"]
    print(f"✅ {result['file_count']} fichier(s) extrait(s)")
    
    # Archiver ZIP traité
    self._archive_zip(zip_file)  # ❌
```

**Après :**
```python
if result["status"] == "SUCCESS":
    extracted_count += 1
    total_files += result["file_count"]
    print(f"✅ {result['file_count']} fichier(s) extrait(s)")
    
    # Supprimer le ZIP après extraction réussie
    self._delete_zip(zip_file)  # ✅
```

#### D. Nouvelle méthode _delete_zip()

**Avant (_archive_zip) :**
```python
def _archive_zip(self, zip_filename: str):
    """Archive le ZIP traité dans input/zip/processed/"""
    
    source = os.path.join(self.zip_dir_fs, zip_filename)
    
    # Ajouter timestamp pour éviter les écrasements
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_name = zip_filename.replace('.zip', '')
    archive_name = f"{base_name}_{timestamp}.zip"
    
    dest = os.path.join(self.archive_dir_fs, archive_name)
    
    try:
        shutil.move(source, dest)
        print(f"   📦 Archivé : {archive_name}")
    except Exception as e:
        print(f"   ⚠️  Erreur archivage : {e}")
```

**Après (_delete_zip) :**
```python
def _delete_zip(self, zip_filename: str):
    """Supprime le fichier ZIP après extraction"""
    
    zip_path = os.path.join(self.zip_dir_fs, zip_filename)
    
    try:
        os.remove(zip_path)
        print(f"   🗑️  Supprimé : {zip_filename}")
    except Exception as e:
        print(f"   ⚠️  Erreur suppression : {e}")
```

#### E. Mise à jour du résumé

**Avant :**
```python
print("\n" + "=" * 80)
print("📊 RÉSUMÉ DÉZIPAGE")
print("=" * 80)
print(f"✅ ZIP extraits     : {extracted_count}")
print(f"❌ ZIP en échec     : {failed_count}")
print(f"📄 Fichiers extraits : {total_files}")
print("=" * 80)
```

**Après :**
```python
print("\n" + "=" * 80)
print("📊 RÉSUMÉ DÉZIPAGE")
print("=" * 80)
print(f"✅ ZIP extraits     : {extracted_count}")
print(f"❌ ZIP en échec     : {failed_count}")
print(f"📄 Fichiers extraits : {total_files}")
print(f"🗑️  ZIP supprimés    : {extracted_count}")  # ✅ Nouveau
print("=" * 80)
```

---

## 🎯 Comportement Final

### Flux de Traitement

```
1. 📦 Lister ZIP dans /input/zip/
2. 📂 Pour chaque ZIP :
   ├─ Extraire vers /extracted/<table_name>/
   ├─ ✅ Extraction réussie ?
   │  ├─ OUI → 🗑️  Supprimer le ZIP
   │  └─ NON → ⚠️  Garder le ZIP (pour débogage)
3. 📊 Afficher résumé
```

### Exemple d'Exécution

```
================================================================================
📦 MODULE 1 : DÉZIPAGE
================================================================================

📂 Répertoire source : /Volumes/.../input/zip
📂 Répertoire cible  : /Volumes/.../extracted

✅ 3 fichier(s) ZIP trouvé(s)

────────────────────────────────────────────────────────────────────────────────
📦 ZIP 1/3: site_20250115.zip
────────────────────────────────────────────────────────────────────────────────
✅ 2 fichier(s) extrait(s)
   → /Volumes/.../extracted/site
   🗑️  Supprimé : site_20250115.zip

────────────────────────────────────────────────────────────────────────────────
📦 ZIP 2/3: customer_20250115.zip
────────────────────────────────────────────────────────────────────────────────
✅ 1 fichier(s) extrait(s)
   → /Volumes/.../extracted/customer
   🗑️  Supprimé : customer_20250115.zip

────────────────────────────────────────────────────────────────────────────────
📦 ZIP 3/3: product_20250115.zip
────────────────────────────────────────────────────────────────────────────────
✅ 5 fichier(s) extrait(s)
   → /Volumes/.../extracted/product
   🗑️  Supprimé : product_20250115.zip

================================================================================
📊 RÉSUMÉ DÉZIPAGE
================================================================================
✅ ZIP extraits     : 3
❌ ZIP en échec     : 0
📄 Fichiers extraits : 8
🗑️  ZIP supprimés    : 3
================================================================================
```

---

## ⚠️  Points d'Attention

### 1. **ZIP en Échec**

Les ZIP qui échouent lors de l'extraction ne sont **PAS supprimés**. Cela permet de :
- Déboguer le problème
- Réessayer manuellement
- Analyser le fichier corrompu

### 2. **Pas de Récupération Possible**

⚠️  **ATTENTION** : Une fois le ZIP supprimé, il n'est **plus récupérable** (pas d'archivage).

**Solutions si besoin de garder les ZIP :**
- Conserver une copie dans un autre emplacement avant traitement
- Utiliser un système de backup externe
- Activer le versioning sur le volume Unity Catalog

### 3. **Sécurité**

Pour éviter les pertes de données :
- Tester d'abord sur l'environnement DEV
- Vérifier que l'extraction est complète avant suppression
- Avoir un backup des ZIP sources

---

## ✅ Avantages de la Suppression

1. **🧹 Espace disque** : Pas d'accumulation de ZIP traités
2. **⚡ Performance** : Pas de copie/déplacement vers archive
3. **🎯 Simplicité** : Structure de répertoires plus simple
4. **💰 Coûts** : Moins de stockage utilisé

---

## 🔄 Pour Revenir à l'Ancien Comportement (Archivage)

Si vous souhaitez revenir à l'archivage :

1. Dans `config.py`, rajouter :
```python
self.archive_dir = f"{self.zip_dir}/processed"
```

2. Dans `unzip_module.py`, remplacer :
```python
self._delete_zip(zip_file)  # Suppression
```
par :
```python
self._archive_zip(zip_file)  # Archivage
```

3. Rétablir la méthode `_archive_zip()` complète

---

## 📊 Comparaison Avant/Après

| Aspect | Avant (Archivage) | Après (Suppression) |
|--------|-------------------|---------------------|
| **Espace disque** | 2x (original + archive) | 1x (fichiers extraits) |
| **Performance** | Lente (move) | Rapide (delete) |
| **Récupération** | Possible | Impossible |
| **Maintenance** | Nettoyer /processed | Aucune |
| **Complexité** | Moyenne | Simple |

---

## 🎯 Recommandations

### Pour Environnement DEV
✅ **Suppression** : Idéal pour tester rapidement

### Pour Environnement PROD
⚠️  **Décision à prendre selon votre politique de rétention**
- Si backup externe existe → Suppression OK
- Si pas de backup → Considérer l'archivage
- Alternative : Versioning Unity Catalog sur le volume

---

## 📝 Checklist de Migration

- [ ] Sauvegarder vos fichiers actuels
- [ ] Remplacer `config.py` par la nouvelle version
- [ ] Remplacer `unzip_module.py` par la nouvelle version
- [ ] Tester sur l'environnement DEV
- [ ] Vérifier qu'aucun ZIP important n'est dans `/input/zip/`
- [ ] Exécuter le module 1
- [ ] Vérifier que les ZIP sont bien supprimés
- [ ] Valider que l'extraction est complète
- [ ] Déployer en INT puis PROD

---

✅ **Modifications terminées !**

Les ZIP seront maintenant supprimés automatiquement après extraction réussie.
