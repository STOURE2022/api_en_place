# 🚀 WAX Data Ingestion Pipeline - Projet Complet

Pipeline d'ingestion de données pour Databricks avec Unity Catalog, validation qualité, et configuration API.

## 📋 Vue d'Ensemble

**WAX** est un pipeline d'ingestion de données complet pour Databricks qui :
- ✅ Dézipe et extrait automatiquement les fichiers sources
- ✅ Valide la qualité des données avec gestion d'erreurs avancée
- ✅ Ingère dans Delta Lake avec 5 modes différents
- ✅ Supporte Unity Catalog natif (pas de DBFS)
- ✅ Configuration centralisée via API REST
- ✅ Logs détaillés et dashboards d'observabilité

---

## 📁 Structure du Projet

```
wax_project_complete/
├── src/                          # Code source du pipeline
│   ├── __init__.py               # Initialisation du module
│   ├── config.py                 # Configuration (avec API) ⭐
│   ├── unzip_module.py           # Module 1 : Dézipage ⭐
│   ├── autoloader_module.py     # Module 2 : Auto Loader
│   ├── main.py                   # Module 3 : Ingestion principale
│   ├── column_processor.py       # Traitement des colonnes
│   ├── validator.py              # Validation des données
│   ├── file_processor.py         # Traitement des fichiers
│   ├── ingestion.py              # Modes d'ingestion
│   ├── delta_manager.py          # Gestion Delta Lake
│   ├── logger_manager.py         # Système de logging
│   ├── dashboards.py             # Dashboards SQL
│   ├── maintenance.py            # Maintenance Delta
│   ├── utils.py                  # Utilitaires
│   └── simple_report_manager.py  # Rapports simples
│
├── config_api/                   # API de configuration
│   ├── config_api.py             # Serveur API Flask
│   ├── config_client.py          # Client Python
│   ├── config_params.json        # Paramètres (dev/int/prd)
│   └── start_api.py              # Script démarrage
│
├── tests/                        # Tests
│   └── test_config_system.py    # Tests configuration API
│
├── docs/                         # Documentation complète
│   ├── README.md                 # Guide API
│   ├── POSTMAN_GUIDE.md          # Tests Postman
│   ├── DATABRICKS_DEPLOYMENT.md  # Déploiement
│   ├── QUICK_START.md            # Démarrage rapide
│   ├── CHANGELOG_UNZIP.md        # Modifications unzip
│   ├── SUMMARY_MODIFICATIONS.md  # Résumé modifs
│   ├── COMPARISON.txt            # Comparaison visuelle
│   └── WAX_Config_API.postman_collection.json
│
├── README.md                     # Ce fichier
├── requirements.txt              # Dépendances Python
├── .gitignore                    # Fichiers à ignorer
└── QUICKSTART.md                 # Démarrage ultra-rapide

⭐ = Fichiers modifiés (suppression ZIP au lieu d'archivage)
```

---

## 🎯 Fonctionnalités Principales

### 🔹 Module 1 : Dézipage (`unzip_module.py`)
- Extrait fichiers ZIP depuis `/input/zip/`
- Organise par table : `site_20250115.zip` → `extracted/site/`
- **Supprime les ZIP** après extraction réussie (pas d'archivage)
- Gestion d'erreurs robuste

### 🔹 Module 2 : Auto Loader (`autoloader_module.py`)
- Lecture automatique des fichiers extraits
- Inférence de schéma
- Checkpoints pour traçabilité
- Support multi-formats (CSV, Parquet, JSON, etc.)

### 🔹 Module 3 : Ingestion (`main.py`)
- **5 modes d'ingestion** : FULL_SNAPSHOT, DELTA_FROM_FLOW, etc.
- **Validation qualité** : Types, nullabilité, doublons
- **Gestion d'erreurs** : REJECT, ICT_DRIVEN, LOG_ONLY
- **Logging complet** : Exécution + qualité

### 🔹 Configuration API
- **Paramètres centralisés** via API REST
- **Multi-environnements** : dev/int/prd
- **Zéro valeur en dur** dans le code
- **Testable avec Postman**

---

## ⚡ Démarrage Rapide

### 1️⃣ Installation

```bash
# Cloner ou extraire le projet
cd wax_project_complete

# Installer les dépendances
pip install -r requirements.txt
```

### 2️⃣ Démarrer l'API de Configuration

```bash
cd config_api
python start_api.py
```

L'API démarre sur `http://localhost:5000`

### 3️⃣ Tester avec Postman

```bash
# Health check
curl http://localhost:5000/health

# Récupérer config DEV
curl http://localhost:5000/config/dev
```

Ou importer la collection : `docs/WAX_Config_API.postman_collection.json`

### 4️⃣ Exécuter le Pipeline

```python
from src.config import create_config_from_api
from src.unzip_module import UnzipManager
from pyspark.sql import SparkSession

# Initialiser Spark
spark = SparkSession.builder.appName("WAX-Pipeline").getOrCreate()

# Récupérer config depuis API
config = create_config_from_api(env="dev")

# Module 1 : Dézipage
unzip_manager = UnzipManager(spark, config)
result = unzip_manager.process_all_zips()

# Modules 2 et 3 : voir docs/
```

---

## 🔧 Configuration

### Variables d'Environnement

```bash
# API Configuration
export CONFIG_API_URL="http://localhost:5000"
export PIPELINE_ENV="dev"

# Unity Catalog (optionnel si API utilisée)
export CATALOG="abu_catalog"
export SCHEMA_FILES="databricksassetbundletest"
export VOLUME="externalvolumetes"
export SCHEMA_TABLES="gdp_poc_dev"
```

### Fichier de Configuration (`config_api/config_params.json`)

```json
{
  "dev": {
    "catalog": "abu_catalog",
    "schema_files": "databricksassetbundletest",
    "volume": "externalvolumetes",
    "schema_tables": "gdp_poc_dev",
    "env": "dev",
    "version": "v1"
  }
}
```

---

## 📚 Documentation Complète

| Document | Description |
|----------|-------------|
| [QUICKSTART.md](QUICKSTART.md) | Démarrage ultra-rapide (5 min) |
| [docs/README.md](docs/README.md) | Guide API détaillé |
| [docs/POSTMAN_GUIDE.md](docs/POSTMAN_GUIDE.md) | Tests Postman complets |
| [docs/DATABRICKS_DEPLOYMENT.md](docs/DATABRICKS_DEPLOYMENT.md) | Déploiement Databricks |
| [docs/CHANGELOG_UNZIP.md](docs/CHANGELOG_UNZIP.md) | Modifications module unzip |

---

## 🎮 Modes d'Ingestion

| Mode | Description | Usage |
|------|-------------|-------|
| `FULL_SNAPSHOT` | Écrase tout | Chargement initial |
| `DELTA_FROM_FLOW` | Append simple | Flux continu |
| `DELTA_FROM_NON_HISTORIZED` | Merge avec update | Mise à jour données |
| `DELTA_FROM_HISTORIZED` | Append avec historique | Données versionnées |
| `FULL_KEY_REPLACE` | Delete + Insert | Remplacement clés |

---

## 🔍 Validation Qualité

### Niveaux de Validation

1. **Nom de fichier** : Pattern de date (yyyy-mm-dd)
2. **Colonnes** : Présence des colonnes attendues
3. **Types** : Validation des types de données
4. **Nullabilité** : Colonnes obligatoires
5. **Doublons** : Clés de merge

### Actions sur Erreur

| Mode | Comportement |
|------|--------------|
| `REJECT` | Supprime les lignes invalides |
| `ICT_DRIVEN` | Flag les erreurs, abort si > tolérance |
| `LOG_ONLY` | Log uniquement, garde tout |

---

## 📊 Observabilité

### Logs

- **Exécution** : `/logs/execution/` → Table `wax_execution_logs`
- **Qualité** : `/logs/quality/` → Table `wax_data_quality_errors`

### Dashboards SQL

```python
from src.dashboards import DashboardManager

dashboard = DashboardManager(spark, config)
dashboard.display_all_dashboards()
```

**Affiche :**
- Dernières exécutions
- Statistiques par table
- Top 10 erreurs
- Tendance 7 jours

---

## 🧪 Tests

```bash
# Tester l'API de configuration
cd tests
python test_config_system.py

# Résultat attendu : 8/8 tests passés
```

---

## 🚀 Déploiement Databricks

### Option 1 : Via Notebook

```python
# Cellule 1 : Installation
%pip install flask requests

# Cellule 2 : Configuration
import os
os.environ['CONFIG_API_URL'] = 'http://cluster-url:8080'

# Cellule 3 : Exécution
from src.config import create_config_from_api
config = create_config_from_api(env="dev")

# Lancer le pipeline...
```

### Option 2 : Via Job Databricks

Voir [docs/DATABRICKS_DEPLOYMENT.md](docs/DATABRICKS_DEPLOYMENT.md) pour le guide complet.

---

## 📦 Dépendances

```
pyspark>=3.3.0
delta-spark>=2.3.0
flask>=2.3.0
requests>=2.31.0
pandas>=1.5.0
openpyxl>=3.1.0
python-pptx>=0.6.21
python-docx>=0.8.11
```

Voir [requirements.txt](requirements.txt) pour la liste complète.

---

## 🔄 Workflow Complet

```mermaid
graph TD
    A[ZIP dans /input/zip/] --> B[Module 1: Unzip]
    B --> C[Fichiers extraits dans /extracted/]
    C --> D[Module 2: Auto Loader]
    D --> E[Validation qualité]
    E --> F{Erreurs ?}
    F -->|< Tolérance| G[Module 3: Ingestion]
    F -->|> Tolérance| H[Logs erreurs]
    G --> I[Tables Delta Lake]
    I --> J[Dashboards]
    H --> J
```

---

## ✅ Avantages du Projet

- 🎯 **Configuration centralisée** : Un seul endroit pour tous les paramètres
- 🌍 **Multi-environnements** : Bascule facile dev/int/prd
- 🔒 **Unity Catalog** : Sécurité et gouvernance des données
- 📊 **Observabilité** : Logs détaillés et dashboards SQL
- 🧹 **Gestion automatique** : Suppression ZIP après traitement
- ⚡ **Performance** : Optimisations Delta Lake (OPTIMIZE, ZORDER)
- 🧪 **Testabilité** : Tests automatiques inclus

---

## 🛠️ Maintenance

### Optimisation Tables Delta

```python
from src.maintenance import MaintenanceManager

maintenance = MaintenanceManager(spark, config)

# Optimiser une table
maintenance.optimize_table("customers", z_order_cols=["customer_id"])

# VACUUM (nettoyer anciennes versions)
maintenance.vacuum_table("customers", retention_hours=168)

# Statistiques
maintenance.analyze_table("customers")
```

---

## 📝 Personnalisation

### Ajouter un Nouvel Environnement

```bash
# Via API
curl -X POST http://localhost:5000/config/staging \
  -H "Content-Type: application/json" \
  -d '{
    "catalog": "staging_catalog",
    "schema_files": "staging_schema",
    "volume": "staging_volume",
    "schema_tables": "staging_tables",
    "env": "staging",
    "version": "v1"
  }'
```

### Modifier les Patterns de Date

Dans `src/config.py` :

```python
self.date_patterns = [
    "dd/MM/yyyy HH:mm:ss",
    "yyyy-MM-dd",
    # Ajouter vos patterns
]
```

---

## 🐛 Troubleshooting

### Problème : API ne démarre pas

```bash
# Vérifier Flask
pip install flask

# Vérifier port disponible
netstat -an | grep 5000
```

### Problème : ZIP non supprimés

→ Vérifier les permissions sur le volume Unity Catalog
→ Consulter les logs pour erreurs

### Problème : Erreurs de typage

→ Vérifier `wax_config.xlsx`
→ Consulter `wax_data_quality_errors`

---

## 📞 Support

- 📖 Documentation complète : `docs/`
- 🧪 Tests automatiques : `tests/`
- 📊 Dashboards : Intégrés dans le code

---

## 🎯 Roadmap

- [ ] Interface web pour gérer les configs
- [ ] Support streaming (Structured Streaming)
- [ ] Intégration CI/CD
- [ ] Notifications (Slack, Email)
- [ ] Métriques Prometheus

---

## 📄 Licence

Projet interne WAX Team.

---

## 👥 Contributeurs

WAX Team - Pipeline d'Ingestion de Données

---

**🚀 Prêt à démarrer ? Consultez [QUICKSTART.md](QUICKSTART.md) !**
