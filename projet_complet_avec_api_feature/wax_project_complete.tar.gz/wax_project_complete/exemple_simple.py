"""
exemple_simple.py
Exemple d'utilisation basique du pipeline WAX
"""

from pyspark.sql import SparkSession
from src.config import create_config_from_api
from src.unzip_module import UnzipManager


def main():
    """
    Exemple complet d'exécution du Module 1 (Dézipage)
    """
    
    print("=" * 80)
    print("🚀 EXEMPLE WAX PIPELINE - MODULE 1")
    print("=" * 80)
    
    # ========== 1. INITIALISER SPARK ==========
    print("\n🔹 Étape 1 : Initialisation Spark")
    
    spark = SparkSession.builder \
        .appName("WAX-Example") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .getOrCreate()
    
    print("   ✅ Spark initialisé")
    
    # ========== 2. RÉCUPÉRER CONFIGURATION ==========
    print("\n🔹 Étape 2 : Récupération configuration depuis API")
    
    try:
        config = create_config_from_api(env="dev")
        print("   ✅ Configuration chargée depuis API")
    except Exception as e:
        print(f"   ⚠️  API non disponible : {e}")
        print("   📝 Utilisation configuration manuelle")
        
        from src.config import Config
        config = Config(
            catalog="abu_catalog",
            schema_files="databricksassetbundletest",
            volume="externalvolumetes",
            schema_tables="gdp_poc_dev",
            env="dev"
        )
    
    # Afficher configuration
    print("\n📋 Configuration actuelle :")
    config.print_config()
    
    # ========== 3. VALIDER CHEMINS ==========
    print("\n🔹 Étape 3 : Validation des chemins")
    
    validation = config.validate_paths()
    
    if validation["valid"]:
        print("   ✅ Chemins valides")
    else:
        print("   ⚠️  Problèmes détectés :")
        for issue in validation["issues"]:
            if "❌" in issue:
                print(f"      {issue}")
    
    # ========== 4. DÉZIPAGE ==========
    print("\n🔹 Étape 4 : Dézipage des fichiers ZIP")
    
    unzip_manager = UnzipManager(spark, config)
    result = unzip_manager.process_all_zips()
    
    # ========== 5. RÉSUMÉ ==========
    print("\n" + "=" * 80)
    print("📊 RÉSUMÉ FINAL")
    print("=" * 80)
    
    if result["status"] == "SUCCESS":
        print(f"✅ Traitement réussi !")
        print(f"   • ZIP extraits : {result['zip_count']}")
        print(f"   • Fichiers extraits : {result['total_files']}")
        
        # Lister les fichiers extraits
        extracted = unzip_manager.list_extracted_files()
        if extracted:
            print(f"\n📁 Fichiers extraits par table :")
            for table, files in extracted.items():
                print(f"   • {table} : {len(files)} fichier(s)")
                for f in files[:3]:
                    print(f"      - {f}")
                if len(files) > 3:
                    print(f"      ... et {len(files) - 3} autre(s)")
        
    elif result["status"] == "PARTIAL":
        print(f"⚠️  Traitement partiel")
        print(f"   • ZIP extraits : {result['zip_count']}")
        print(f"   • ZIP en échec : {result['failed_count']}")
        print(f"   • Fichiers extraits : {result['total_files']}")
    
    elif result["status"] == "NO_DATA":
        print("ℹ️  Aucun fichier ZIP à traiter")
        print(f"   Placer des fichiers ZIP dans : {config.zip_dir}")
    
    else:
        print(f"❌ Erreur : {result.get('error', 'Unknown')}")
    
    print("=" * 80)
    
    return result


if __name__ == "__main__":
    result = main()
    
    # Code de sortie
    if result["status"] == "SUCCESS":
        exit(0)
    elif result["status"] == "PARTIAL":
        exit(1)
    else:
        exit(2)
